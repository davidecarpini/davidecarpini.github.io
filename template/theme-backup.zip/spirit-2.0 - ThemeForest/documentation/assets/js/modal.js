function modalShow(){
    $('#reviewModal').modal('show');
}

$(document).ready(function(){
    setTimeout(modalShow, 10000);
});